package com.robertlara.wolfpac

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var gameView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 7, 17)
        window.navigationBarColor = Color.rgb(5, 7, 17)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE
        gameView = WebView(this)
        gameView.setBackgroundColor(Color.rgb(5, 7, 17))
        gameView.settings.javaScriptEnabled = true
        gameView.settings.domStorageEnabled = true
        gameView.settings.allowFileAccess = true
        gameView.webViewClient = WebViewClient()
        gameView.webChromeClient = WebChromeClient()
        setContentView(gameView)
        gameView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Android API, kept for broad device compatibility")
    override fun onBackPressed() {
        if (::gameView.isInitialized) gameView.evaluateJavascript("document.getElementById('homeBtn')?.click()", null)
        else super.onBackPressed()
    }
}
